package com.example.hesapmakinesi

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.hesapmakinesi.databinding.ActivityMainBinding
var currentInput=""
var result=0
class MainActivity : AppCompatActivity() {
    private lateinit var tasarim: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tasarim =ActivityMainBinding.inflate(layoutInflater)
        setContentView(tasarim.root)
         tasarim.button0.setOnClickListener{
             numberClick(0)
         }
        tasarim.button1.setOnClickListener{
            numberClick(1)
        }
        tasarim.button2.setOnClickListener{
            numberClick(2)
        }
        tasarim.button3.setOnClickListener{
            numberClick(3)
        }
        tasarim.button4.setOnClickListener{
            numberClick(4)
        }
        tasarim.button5.setOnClickListener{
            numberClick(5)
        }
        tasarim.button6.setOnClickListener{
            numberClick(6)
        }
        tasarim.button7.setOnClickListener{
            numberClick(7)
        }
        tasarim.button8.setOnClickListener{
            numberClick(8)
        }
        tasarim.button9.setOnClickListener{
            numberClick(9)
        }
        tasarim.buttonToplama.setOnClickListener{
            onPlusClick()
        }
        tasarim.buttonEqual.setOnClickListener{
            onEqualClick()
        }

    }
    fun numberClick(number:Int) {
        currentInput+= number.toString()
        tasarim.textView.setText(currentInput)
    }
    fun onPlusClick(){
        result+= currentInput.toIntOrNull() ?: 0
        currentInput=""
        tasarim.textView.setText(currentInput)
    }
    fun onEqualClick(){
        result+= currentInput.toIntOrNull() ?: 0
        tasarim.textView.setText(result.toString())
        currentInput=""
        result=0;
    }
}
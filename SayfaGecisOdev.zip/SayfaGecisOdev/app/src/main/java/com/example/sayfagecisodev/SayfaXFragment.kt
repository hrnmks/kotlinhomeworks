package com.example.sayfagecisodev

import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController

class SayfaXFragment : Fragment(R.layout.fragment_sayfa_x) {
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val navController = findNavController()

        val btnToB = view.findViewById<Button>(R.id.button5)
        btnToB.setOnClickListener {
            navController.navigate(R.id.action_sayfaXFragment_to_sayfaYFragment)
        }
    }
}
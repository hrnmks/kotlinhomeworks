package com.example.sayfagecisodev

import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController

class SayfaBFragment : Fragment(R.layout.fragment_sayfa_b) {
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val navController = findNavController()

        val btnToY = view.findViewById<Button>(R.id.button4)
        btnToY.setOnClickListener {
            navController.navigate(R.id.action_sayfaBFragment_to_sayfaYFragment)
        }
    }
}
package com.example.sayfagecisodev

import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController

class SayfaAFragment : Fragment(R.layout.fragment_sayfa_a) {
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val navController = findNavController()

        val btnToB = view.findViewById<Button>(R.id.button3)
        btnToB.setOnClickListener {
            navController.navigate(R.id.action_sayfaAFragment_to_sayfaBFragment)
        }
    }
}